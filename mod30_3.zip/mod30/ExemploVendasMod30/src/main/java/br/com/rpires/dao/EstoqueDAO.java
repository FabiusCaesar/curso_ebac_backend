package br.com.rpires.dao;

import br.com.rpires.dao.generic.GenericDAO;
import br.com.rpires.domain.Estoque;

import java.sql.PreparedStatement;
import java.sql.SQLException;

/**
 * @author FabiusCaesar
 */
public class EstoqueDAO extends GenericDAO<Estoque, Integer> implements IEstoqueDAO {

    @Override
    public Class<Estoque> getTipoClasse() {
        return Estoque.class;
    }

    @Override
    public void atualiarDados(Estoque entity, Estoque entityCadastrado) {
        entityCadastrado.setQuantidade(entity.getQuantidade());
        entityCadastrado.setUpdatedAt(entity.getUpdatedAt());
    }

    @Override
    protected String getQueryInsercao() {
        return "INSERT INTO tb_estoque (produto_id, quantidade, updated_at) VALUES (?, ?, NOW())";
    }

    @Override
    protected String getQueryExclusao() {
        return "DELETE FROM tb_estoque WHERE produto_id = ?";
    }

    @Override
    protected String getQueryAtualizacao() {
        return "UPDATE tb_estoque SET quantidade = ?, updated_at = NOW() WHERE produto_id = ?";
    }

    @Override
    protected void setParametrosQueryInsercao(PreparedStatement stmInsert, Estoque entity) throws SQLException {
        stmInsert.setLong(1, entity.getId());          // produto_id (já deve vir preenchido)
        stmInsert.setInt(2, entity.getQuantidade());   // quantidade
        // updated_at = NOW()
    }

    @Override
    protected void setParametrosQueryExclusao(PreparedStatement stmDelete, Integer valor) throws SQLException {
        // valor = produto_id
        stmDelete.setLong(1, valor);
    }

    @Override
    protected void setParametrosQueryAtualizacao(PreparedStatement stmUpdate, Estoque entity) throws SQLException {
        stmUpdate.setInt(1, entity.getQuantidade());   // quantidade
        stmUpdate.setLong(2, entity.getId());          // WHERE produto_id = ?
    }

    @Override
    protected void setParametrosQuerySelect(PreparedStatement stmSelect, Integer valor) throws SQLException {
        // usado pelo GenericDAO.consultar()
        stmSelect.setLong(1, valor); // WHERE <pk> = ?
    }
}
