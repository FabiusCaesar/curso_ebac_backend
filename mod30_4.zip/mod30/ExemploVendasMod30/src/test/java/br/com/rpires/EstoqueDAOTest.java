package br.com.rpires;

import br.com.rpires.dao.EstoqueDAO;
import br.com.rpires.dao.IEstoqueDAO;
import br.com.rpires.dao.IProdutoDAO;
import br.com.rpires.dao.ProdutoDAO;
import br.com.rpires.domain.Produto;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;

import java.math.BigDecimal;

/**
 * @author FabiusCaesar
 */
public class EstoqueDAOTest {

    private IProdutoDAO produtoDAO;
    private IEstoqueDAO estoqueDAO;

    private Produto produto;

    @Before
    public void setUp() throws Exception {

        produtoDAO = new ProdutoDAO();
        estoqueDAO = new EstoqueDAO();

        produto = new Produto();
        produto.setCodigo("P-EST-" + System.currentTimeMillis());
        produto.setNome("Produto Teste");
        produto.setModelo("Modelo Teste"); // campo que você adicionou
        produto.setDescricao("Produto para testes de estoque");
        produto.setValor(BigDecimal.valueOf(10.00));

        produtoDAO.cadastrar(produto);
        Assert.assertNotNull(produto.getId());
    }

    @After
    public void tearDown() {
        // limpa estoque (se existir)
        try {
            if (produto != null && produto.getId() != null) {
                estoqueDAO.excluir(produto.getId());
            }
        } catch (Exception ignore) {}

        // exclui produto
        try {
            if (produto != null && produto.getId() != null) {
                produtoDAO.excluir(produto.getId());
            }
        } catch (Exception ignore) {}
    }
}
