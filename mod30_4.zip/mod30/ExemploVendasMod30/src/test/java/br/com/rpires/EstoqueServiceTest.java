package br.com.rpires;

import br.com.rpires.dao.EstoqueDAO;
import br.com.rpires.dao.IEstoqueDAO;
import br.com.rpires.dao.IProdutoDAO;
import br.com.rpires.dao.ProdutoDAO;
import br.com.rpires.domain.Produto;
import br.com.rpires.exceptions.DAOException;
import br.com.rpires.exceptions.MaisDeUmRegistroException;
import br.com.rpires.exceptions.TableException;
import br.com.rpires.exceptions.TipoChaveNaoEncontradaException;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import java.math.BigDecimal;

/**
 * @author FabiusCaesar
 */
public class EstoqueServiceTest {

    private IProdutoDAO produtoDAO;
    private IEstoqueDAO estoqueDAO;
    private IEstoqueService estoqueService;

    private Produto produto;

    @Before
    public void setUp() throws Exception {
        produtoDAO = new ProdutoDAO();
        estoqueDAO = new EstoqueDAO();

        // A Service concreta receberá o DAO por injeção simples no próximo passo
        estoqueService = new EstoqueService(estoqueDAO);

        // cria um produto válido
        produto = new Produto();
        produto.setCodigo("P-EST-" + System.currentTimeMillis());
        produto.setNome("Produto Teste");
        produto.setModelo("Modelo Teste"); // campo que você adicionou
        produto.setDescricao("Produto para testes de estoque");
        produto.setValor(BigDecimal.valueOf(10.00));

        produtoDAO.cadastrar(produto);
        Assert.assertNotNull(produto.getId());
    }

    @After
    public void tearDown() throws Exception {
        // limpa estoque (se existir)
        try {
            if (produto != null && produto.getId() != null) {
                estoqueDAO.excluir(produto.getId());
            }
        } catch (DAOException ignore) {}

        // exclui produto
        if (produto != null && produto.getId() != null) {
            produtoDAO.excluir(produto.getId());
        }
    }

    @Test
    public void deveCriarRegistroDeEstoqueSeAusenteEInicializarEmZero()
            throws DAOException, TipoChaveNaoEncontradaException, MaisDeUmRegistroException, TableException {
        Long produtoId = produto.getId();

        // Garante que não existe (idempotente para o teste)
        try { estoqueDAO.excluir(produtoId); } catch (DAOException ignore) {}

        // Act
        estoqueService.criarSeAusente(produtoId);
        Integer quantidade = estoqueService.consultarQuantidade(produtoId);

        // Assert
        Assert.assertNotNull(quantidade);
        Assert.assertEquals(Integer.valueOf(0), quantidade);
    }

    @Test
    public void deveIncrementarEDecrementarComSaldoSuficiente()
            throws DAOException, TipoChaveNaoEncontradaException, MaisDeUmRegistroException, TableException {
        Long produtoId = produto.getId();

        estoqueService.criarSeAusente(produtoId);
        Assert.assertEquals(Integer.valueOf(0), estoqueService.consultarQuantidade(produtoId));

        // +10
        estoqueService.incrementar(produtoId, 10);
        Assert.assertEquals(Integer.valueOf(10), estoqueService.consultarQuantidade(produtoId));

        // -3 (saldo suficiente)
        estoqueService.decrementarOuFalhar(produtoId, 3);
        Assert.assertEquals(Integer.valueOf(7), estoqueService.consultarQuantidade(produtoId));
    }

    @Test
    public void deveFalharAoDecrementarComSaldoInsuficiente()
            throws DAOException, TipoChaveNaoEncontradaException, MaisDeUmRegistroException, TableException {
        Long produtoId = produto.getId();

        estoqueService.criarSeAusente(produtoId);
        estoqueService.incrementar(produtoId, 2);
        Assert.assertEquals(Integer.valueOf(2), estoqueService.consultarQuantidade(produtoId));

        try {
            estoqueService.decrementarOuFalhar(produtoId, 5); // pede mais do que tem
            Assert.fail("Era esperado lançar exceção por estoque insuficiente");
        } catch (RuntimeException ex) {
            // Mantemos genérico por enquanto para não depender de uma exception custom ainda.
            // Quando criarmos EstoqueInsuficienteException, atualizamos este assert.
            Assert.assertTrue(
                    "Mensagem deve indicar estoque insuficiente",
                    ex.getMessage() != null && ex.getMessage().toLowerCase().contains("estoque insuficiente")
            );
        }

        // saldo deve permanecer inalterado após falha
        Assert.assertEquals(Integer.valueOf(2), estoqueService.consultarQuantidade(produtoId));
    }
}